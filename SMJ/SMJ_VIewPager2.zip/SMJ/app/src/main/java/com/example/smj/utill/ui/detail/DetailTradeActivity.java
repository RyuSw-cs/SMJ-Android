package com.example.smj.utill.ui.detail;

public class DetailTradeActivity {
}
